create definer = root@localhost view vw_dashboard_financeiro as
select count(`libritech`.`multas`.`id_multa`)         AS `total_multas_pagas`,
       coalesce(sum(`libritech`.`multas`.`valor`), 0) AS `arrecadacao_total`
from `libritech`.`multas`
where (`libritech`.`multas`.`pago` = 1);

