create definer = root@localhost trigger trg_preventiva_estoque
    before update
    on livros
    for each row
BEGIN
    IF NEW.quantidade_estoque < 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "ERRO: A quantidade em estoque nao pode ser negativa.";
    END IF;
END;

