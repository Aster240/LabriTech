create definer = root@localhost view vw_ranking_leitura as
select `l`.`titulo` AS `titulo`, count(`e`.`id_emprestimo`) AS `total_emprestimos`
from (`libritech`.`livros` `l` join `libritech`.`emprestimos` `e` on ((`l`.`id_livro` = `e`.`id_livro_fk`)))
group by `l`.`titulo`
order by `total_emprestimos` desc
limit 10;

grant select on table vw_ranking_leitura to usr_aluno@localhost;

grant select on table vw_ranking_leitura to usr_bibliotecario@localhost;

