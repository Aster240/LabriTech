create
    definer = root@localhost procedure sp_renovar_emprestimo(IN p_id_emprestimo int)
BEGIN
    DECLARE v_status_livro VARCHAR(20);

    -- Busca status do livro relacionado ao emprestimo
    SELECT l.status INTO v_status_livro
    FROM emprestimos e JOIN livros l ON e.id_livro_fk = l.id_livro
    WHERE e.id_emprestimo = p_id_emprestimo;

    IF v_status_livro = 'RESERVADO' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "ERRO: Livro reservado ou indisponivel.";
    ELSE
        UPDATE emprestimos SET data_prevista = DATE_ADD(data_prevista, INTERVAL 7 DAY)
        WHERE id_emprestimo = p_id_emprestimo;
    END IF;
END;

grant execute on procedure sp_renovar_emprestimo to usr_bibliotecario@localhost;

