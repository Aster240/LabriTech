create definer = root@localhost trigger trg_auditoria_delecao
    after delete
    on livros
    for each row
BEGIN
    INSERT INTO log_auditoria (tabela_afetada, acao, usuario_responsavel, dados_antigos)
    VALUES ('livros', 'DELETE', USER(), CONCAT('ID: ', OLD.id_livro, ', Titulo: ', OLD.titulo, ', ISBN: ', OLD.isbn));
END;

