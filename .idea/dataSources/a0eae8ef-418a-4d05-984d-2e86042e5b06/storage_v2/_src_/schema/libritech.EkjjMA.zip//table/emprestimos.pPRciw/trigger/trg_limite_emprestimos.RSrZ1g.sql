create definer = root@localhost trigger trg_limite_emprestimos
    before insert
    on emprestimos
    for each row
BEGIN
    DECLARE v_qtd_livros INT;
    SELECT COUNT(*) INTO v_qtd_livros FROM emprestimos
    WHERE id_usuario_fk = NEW.id_usuario_fk AND data_devolucao IS NULL;

    IF v_qtd_livros >= 3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "ERRO: Limite de 3 livros emprestados atingido.";
    END IF;
END;

