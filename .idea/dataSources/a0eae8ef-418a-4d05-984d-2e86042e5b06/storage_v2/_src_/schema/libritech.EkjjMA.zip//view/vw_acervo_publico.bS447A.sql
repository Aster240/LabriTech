create definer = root@localhost view vw_acervo_publico as
select `libritech`.`livros`.`titulo`                                                                     AS `Titulo`,
       `libritech`.`livros`.`autor`                                                                      AS `Autor`,
       `libritech`.`livros`.`status`                                                                     AS `Status Disponibilidade`,
       (case
            when (`libritech`.`livros`.`quantidade_estoque` > 0) then 'Disponivel'
            else 'Esgotado' end)                                                                         AS `Disponibilidade`
from `libritech`.`livros`;

grant select on table vw_acervo_publico to usr_aluno@localhost;

grant select on table vw_acervo_publico to usr_bibliotecario@localhost;

grant select on table vw_acervo_publico to usr_estagiario@localhost;

