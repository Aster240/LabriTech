create
    definer = root@localhost procedure sp_transacao_emprestimo(IN p_id_usuario int, IN p_id_livro int, IN p_dias_prazo int)
BEGIN
    DECLARE v_estoque INT;
    DECLARE v_pendencias INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;
        SELECT quantidade_estoque INTO v_estoque FROM livros WHERE id_livro = p_id_livro FOR UPDATE;

        IF v_estoque <= 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "ERRO: O livro nao esta disponivel em estoque.";
        END IF;

        -- Verifica se tem multas pendentes
        SELECT COUNT(*) INTO v_pendencias
        FROM multas m JOIN emprestimos e ON m.id_emprestimo_fk = e.id_emprestimo
        WHERE e.id_usuario_fk = p_id_usuario AND m.pago = 0;

        IF v_pendencias > 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "ERRO: Usuario possui multas pendentes!";
        END IF;

        -- esperar o paramêtro do java, FALTAVA ISSO :/ (7 ou 14 dias) //
        INSERT INTO emprestimos (id_usuario_fk, id_livro_fk, data_prevista)
        VALUES (p_id_usuario, p_id_livro, DATE_ADD(CURRENT_DATE, INTERVAL p_dias_prazo DAY));

        -- Baixa no estoque
        UPDATE livros SET quantidade_estoque = quantidade_estoque - 1 WHERE id_livro = p_id_livro;
    COMMIT;
END;

grant execute on procedure sp_transacao_emprestimo to usr_bibliotecario@localhost;

grant execute on procedure sp_transacao_emprestimo to usr_estagiario@localhost;

