create
    definer = root@localhost procedure sp_historico_usuario(IN p_id_aluno int)
BEGIN
    SELECT l.titulo, e.data_saida, e.data_prevista, e.data_devolucao
    FROM emprestimos e
    JOIN livros l ON e.id_livro_fk = l.id_livro
    WHERE e.id_usuario_fk = p_id_aluno;
END;

grant execute on procedure sp_historico_usuario to usr_aluno@localhost;

