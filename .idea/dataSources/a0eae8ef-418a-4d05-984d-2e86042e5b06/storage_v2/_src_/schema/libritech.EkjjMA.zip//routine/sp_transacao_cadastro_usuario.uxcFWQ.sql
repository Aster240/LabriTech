create
    definer = root@localhost procedure sp_transacao_cadastro_usuario(IN p_name varchar(100), IN p_cpf varchar(11),
                                                                     IN p_email varchar(100), IN p_senha varchar(255),
                                                                     IN p_tipo varchar(20),
                                                                     IN p_logradouro varchar(150),
                                                                     IN p_bairro varchar(50), IN p_cidade varchar(50),
                                                                     IN p_uf char(2))
BEGIN
    DECLARE v_novo_id_usuario INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
        INSERT INTO usuarios (nome,cpf,email,senha,tipo)
        VALUES (p_name, p_cpf, p_email, p_senha, p_tipo);

        SET v_novo_id_usuario = LAST_INSERT_ID();

        INSERT INTO enderecos (logradouro, bairro, cidade, uf, id_usuario_fk)
        VALUES (p_logradouro, p_bairro, p_cidade, p_uf, v_novo_id_usuario);
    COMMIT;
END;

grant execute on procedure sp_transacao_cadastro_usuario to usr_bibliotecario@localhost;

