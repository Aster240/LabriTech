create
    definer = root@localhost procedure sp_transacao_devolucao(IN p_id_emprestimo int)
BEGIN
    DECLARE v_id_livro INT;
    DECLARE v_data_prevista DATE;
    DECLARE v_atraso INT;

    SELECT id_livro_fk, data_prevista INTO v_id_livro, v_data_prevista
    FROM emprestimos WHERE id_emprestimo = p_id_emprestimo;

    START TRANSACTION;
        -- Registra devolução
        UPDATE emprestimos SET data_devolucao = NOW() WHERE id_emprestimo = p_id_emprestimo;
        -- Sobe estoque
        UPDATE livros SET quantidade_estoque = quantidade_estoque + 1 WHERE id_livro = v_id_livro;

        -- Calcula multa se houver atraso (R$ 2.00 por dia)
        SET v_atraso = DATEDIFF(CURDATE(), v_data_prevista);
        IF v_atraso > 0 THEN
            INSERT INTO multas (id_emprestimo_fk, valor, pago) VALUES (p_id_emprestimo, v_atraso * 2.00, 0);
        END IF;
    COMMIT;
END;

grant execute on procedure sp_transacao_devolucao to usr_bibliotecario@localhost;

